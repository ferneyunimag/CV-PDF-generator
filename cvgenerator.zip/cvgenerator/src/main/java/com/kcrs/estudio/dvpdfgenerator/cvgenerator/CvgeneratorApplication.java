package com.kcrs.estudio.dvpdfgenerator.cvgenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CvgeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CvgeneratorApplication.class, args);
	}

}
