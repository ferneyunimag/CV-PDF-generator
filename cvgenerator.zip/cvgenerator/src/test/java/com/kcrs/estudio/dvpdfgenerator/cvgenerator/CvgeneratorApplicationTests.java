package com.kcrs.estudio.dvpdfgenerator.cvgenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CvgeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
